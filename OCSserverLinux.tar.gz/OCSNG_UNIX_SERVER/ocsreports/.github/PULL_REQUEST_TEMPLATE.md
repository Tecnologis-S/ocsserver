### Status
**READY/IN DEVELOPMENT/HOLD** (remove the irrevelant words)

### Description
A few sentences describing the overall goals of the pull request's commits.

### Documentation
In the case, your pull request need the documentation to be modified, please say it here.
You can also directly create a pull request for the documentation here : https://github.com/OCSInventory-NG/Wiki

Note : Merge process will be faster if the documentation is already written


