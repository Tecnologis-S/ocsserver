## Important notes
Please, don't mistake OCSInventory-server with OCSInventory-ocsreports :
* OCSInventory-server : Communication server that manage the inventory
* OCSInventory-ocsreports : Web interface of OCS Inventory

## General informations
Operating system :

## Server informations
Perl version :
Mysql / Mariadb / Percona version :  

## Status
**READY/IN DEVELOPMENT/HOLD**

## Description
A few sentences describing the overall goals of the pull request's commits.
